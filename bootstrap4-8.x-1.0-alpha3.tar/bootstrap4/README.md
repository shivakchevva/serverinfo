# Boostrap 4 master theme

## Initiate SASS compilation

Run 

```
npm install 
npm run sass-compile
#OR npm run sass-compile-watch
```
